<!-- Banner -->
<div id="banner">

 <div id="Logout">
 	Willkommen <span id="UserInfo"><?php echo $SYSTEM["username"]; ?></span>,
 	<a id="Logout_link" href="main.php?mod=logout">Logout</a>
 </div> 

 <div id="CompanyName"><?php echo $SYSTEM["company"]; ?></div>
 <div id="SystemName">BlueNote by Matti Maier Internet Solutions <?php echo date("Y"); ?></div>

</div>