<form id="login_form" method="POST">
	<label for="pin">PIN:</label>
	<input type="password" name="pin" />
	<button type="submit" data-theme="b" name="submit" value="submit-value">Anmelden</button>
</form>