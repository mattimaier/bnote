<form id="reason_form" method="POST">
	<label for="reason">Bitte gebe eine kurze Begründung an</label>
	<input type="text" name="reason" />
	<input type="hidden" name="rid" value="0" />
	<button type="submit" data-theme="a" name="submit" value="submit-value">Nicht Teilnehmen</button>
</form>