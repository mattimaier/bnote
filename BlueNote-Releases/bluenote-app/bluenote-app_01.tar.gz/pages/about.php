<h3>Kontaktinformationen des Entwicklers</h3>
<p><b>Matti Maier Internet Solutions</b><br />
Parkstr. 18 &#183; 73630 Remshalden<br />
<a href="http://www.mattimaier.de" target="_blank" data-role="button">Website</a><br />
<a href="mailto:info@mattimaier.de" data-role="button">E-Mail senden</a><br />
<a href="tel:+498980912915" data-role="button">Anrufen</a>
</p>