<?php
session_start();

include "core/main.php";
new Main();

?>