# PATCH for BNote
# BNote Version 2
# Patch Version: 3.1

# How to install patch?

1. Copy update_db.php to the root folder of your bluenote application.
2. Execute the update_db.php script.
3. Remove update_db.php and bluenote_version from the root folder of your bluenote application.
4. Copy all files from the patch to the bluenote folder, except update_db.php, readme.txt and release_notes.txt.