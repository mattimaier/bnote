# Hotfix for BlueNote
# BlueNote Version 2.1
# Hotfix: 2.1.2

# How to install patch?

Copy all files from the patch to the bluenote folder except readme.txt and release_notes.txt.
