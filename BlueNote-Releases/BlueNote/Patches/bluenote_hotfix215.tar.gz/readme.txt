# PATCH for BlueNote
# BlueNote Version 2
# Patch Version: 1

# How to install patch?

1. Copy all files from the patch to the bluenote folder, except readme.txt and release_notes.txt.
