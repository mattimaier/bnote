<div id="rehearsal_boxes">
</div>