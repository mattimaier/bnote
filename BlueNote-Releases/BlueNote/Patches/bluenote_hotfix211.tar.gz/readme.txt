# Hotfix for BlueNote
# BlueNote Version 2.1
# Hotfix: 2.1.1

# How to install patch?

1. Copy all files from the patch to the bluenote folder except readme.txt and release_notes.txt.
2. Execute the update_db.php script in the root folder. Check the log for success.
3. Remove update_db.php from the root folder of your bluenote application.