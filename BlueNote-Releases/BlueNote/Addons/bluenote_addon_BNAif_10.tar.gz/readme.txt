##
## BlueNote App Interface Add-on
##

This addon adds an interface for (mobile) applications to the blue instance.
To install the addon just copy the files to your BlueNote root folder.

## REQUIRED VERSION
2.1.6