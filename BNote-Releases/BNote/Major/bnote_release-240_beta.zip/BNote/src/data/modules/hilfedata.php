<?php

class HilfeData {
	// dummy
}

?>