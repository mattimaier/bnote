lessc default/bnote.less > default/bnote.css
lessc dark/bnote.less > dark/bnote.css
lessc green/bnote.less > green/bnote.css
lessc orange/bnote.less > orange/bnote.css
lessc red/bnote.less > red/bnote.css
