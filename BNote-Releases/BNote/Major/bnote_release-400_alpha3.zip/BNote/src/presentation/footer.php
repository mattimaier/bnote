<!-- Footer -->
<script src="<?php echo $GLOBALS["DIR_LIB"]; ?>bootstrap-5.1.3-dist/js/bootstrap.bundle.min.js"></script>