<?php

class AdminData extends AbstractData {
	
	function __construct($dir_prefix = "") {
		$this->init($dir_prefix);
	}
	
}

?>