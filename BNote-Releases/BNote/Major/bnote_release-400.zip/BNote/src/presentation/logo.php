<!-- Logo -->
 <div id="logoLoginContainer">
 	<div id="logoLogin">
		BNote<br/>
		<img src="style/images/BNote_Logo_blue_on_white_192px.png"/>
   </div>
   </div>
 <?php 
