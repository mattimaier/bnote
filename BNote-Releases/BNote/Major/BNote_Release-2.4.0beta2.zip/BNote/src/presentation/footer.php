<!-- Footer -->
<div id="footer">
	<div id="footerConent">
 	  <div id="SystemName">BNote by Matti Maier Internet Solutions <?php echo date("Y"); ?></div>
		  </div> 
</div>