sap.ui.controller("bnote.reservation",{
	
});