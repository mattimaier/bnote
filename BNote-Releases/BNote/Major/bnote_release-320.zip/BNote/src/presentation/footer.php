<!-- Footer -->
<div id="footer">
	<div id="footerConent">
		<div id="SystemName">
			BNote <?php echo $GLOBALS["system_data"]->getVersion(); ?> by Matti Maier und Stefan Kreminski BNote Software GbR
		</div>
	</div>
</div>
