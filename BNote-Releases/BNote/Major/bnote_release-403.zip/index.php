<?php
header("location: BNote/index.php");
?>