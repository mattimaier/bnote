# BNote
# by Matti Maier und Stefan Kreminski
# www.bnote.info
# License GPLv3

Requirements and installation guide can be found under
https://github.com/mattimaier/bnote/wiki/Installation-Guide
