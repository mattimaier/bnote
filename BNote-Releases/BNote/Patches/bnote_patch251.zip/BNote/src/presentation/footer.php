<!-- Footer -->
<div id="footer">
	<div id="footerConent">
		<div id="SystemName">
			BNote <?php echo $GLOBALS["system_data"]->getVersion(); ?> by Matti Maier Internet Solutions
		</div>
	</div>
</div>
